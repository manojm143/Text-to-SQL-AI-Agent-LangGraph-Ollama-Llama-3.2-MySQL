import mysql.connector


def get_database_schema(
    host,
    user,
    password,
    database
):
    # Connect to MySQL
    conn = mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    cursor = conn.cursor()

    database_info = {
        "database": database,
        "tables": {}
    }

    # Get all tables
    cursor.execute("""
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = %s
          AND TABLE_TYPE = 'BASE TABLE'
        ORDER BY TABLE_NAME
    """, (database,))

    tables = cursor.fetchall()

    # Process every table
    for (table_name,) in tables:

        # Get column names and data types
        cursor.execute("""
            SELECT
                COLUMN_NAME,
                COLUMN_TYPE
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = %s
              AND TABLE_NAME = %s
            ORDER BY ORDINAL_POSITION
        """, (database, table_name))

        columns = cursor.fetchall()

        column_info = []

        for column_name, data_type in columns:
            column_info.append({
                "column_name": column_name,
                "data_type": data_type
            })

        # Get top 5 rows
        cursor.execute(
            f"SELECT * FROM `{table_name}` LIMIT 5"
        )

        rows = cursor.fetchall()

        row_column_names = [
            description[0]
            for description in cursor.description
        ]

        top_5_rows = []

        for row in rows:
            row_dict = dict(zip(row_column_names, row))
            top_5_rows.append(row_dict)

        # Store table information
        database_info["tables"][table_name] = {
            "columns": column_info,
            "top_5_rows": top_5_rows
        }

    cursor.close()
    conn.close()

    return database_info


# --------------------------------
# CALL FUNCTION HERE
# --------------------------------

def result():
    schema = get_database_schema(
    host="localhost",
    user="root",
    password="Dream11198",
    database="projectsql")
    return schema
def execute_query(query):
    # Connect to MySQL
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Dream11198",  
        database="projectsql"
    )
    cursor = conn.cursor()
    cursor.execute(query)
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    return result
print(result())
