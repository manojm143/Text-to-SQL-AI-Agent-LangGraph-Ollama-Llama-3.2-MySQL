from langgraph.graph import StateGraph, END

from schema import agentschema

from agent import (
    curated_ques,
    prompt_query_context,
    generate_sql_query,
    execute_sql_query,
    final_answer
)


# ---------------------------------------
# Create graph
# ---------------------------------------

graph = StateGraph(agentschema)


# ---------------------------------------
# Add nodes
# ---------------------------------------

graph.add_node(
    "curated_ques",
    curated_ques
)

graph.add_node(
    "prompt_query_context",
    prompt_query_context
)

graph.add_node(
    "generate_sql_query",
    generate_sql_query
)

graph.add_node(
    "execute_sql_query",
    execute_sql_query
)

graph.add_node(
    "final_answer",
    final_answer
)


# ---------------------------------------
# Set starting node
# ---------------------------------------

graph.set_entry_point("curated_ques")


# ---------------------------------------
# Connect nodes
# ---------------------------------------

graph.add_edge(
    "curated_ques",
    "prompt_query_context"
)

graph.add_edge(
    "prompt_query_context",
    "generate_sql_query"
)

graph.add_edge(
    "generate_sql_query",
    "execute_sql_query"
)

graph.add_edge(
    "execute_sql_query",
    "final_answer"
)

graph.add_edge(
    "final_answer",
    END
)


# ---------------------------------------
# Compile
# ---------------------------------------

app = graph.compile()


# ---------------------------------------
# Initial state
# ---------------------------------------

initial_state = agentschema(
    user_question="how many unique customers are there?"
)


# ---------------------------------------
# Run graph
# ---------------------------------------

result = app.invoke(initial_state)


# ---------------------------------------
# Print results
# ---------------------------------------

print("\n==============================")
print("CURATED QUESTION")
print("==============================")

print(result["curated_ques"])


print("\n==============================")
print("GENERATED SQL")
print("==============================")

print(result["generated_sql_query"])


print("\n==============================")
print("SQL EXECUTION RESULT")
print("==============================")

print(result["sql_query_execution_result"])


print("\n==============================")
print("FINAL ANSWER")
print("==============================")

print(result["final_answer"])