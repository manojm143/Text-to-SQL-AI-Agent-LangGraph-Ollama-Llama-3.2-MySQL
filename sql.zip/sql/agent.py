from langchain_ollama import ChatOllama

from schema import agentschema
from db_conn import result, execute_query


llm = ChatOllama(
    model="llama3.2:1b"
)


def curated_ques(state: agentschema) -> agentschema:

    user_question = state.user_question

    response = llm.invoke(
        f"""
        Curate and clarify the following user's question.

        User question:
        {user_question}

        Return only the improved question.
        """
    )

    state.curated_ques = response.content

    return state


def prompt_query_context(state: agentschema) -> agentschema:

    curated_ques = state.curated_ques

    db_schema_details = result()

    response = llm.invoke(
        f"""
        Create a detailed prompt for generating SQL.

        Curated question:
        {curated_ques}

        Database schema:
        {db_schema_details}

        The SQL must use only the tables and columns
        available in the database schema with same table names and column names.
        """
    )

    state.prompt_query_context = response.content

    return state


def generate_sql_query(state: agentschema) -> agentschema:

    prompt_query_content = state.prompt_query_context

    response = llm.invoke(
        f"""
You are a MySQL SQL query generator.

Generate a SQL query using ONLY the tables and columns
provided in the database schema.

STRICT RULES:

1. Use exact table names from the schema.
2. Use exact column names from the schema.
3. Do not invent table names.
4. Do not invent column names.
5. Return ONLY the SQL query.
6. Do NOT use markdown.
7. Do NOT use ```sql.
8. Do NOT use ```.
9. Do NOT provide any explanation.

Database schema and context:
{prompt_query_content}
"""
    )

    state.generated_sql_query = response.content.strip()

    return state


def execute_sql_query(state: agentschema) -> agentschema:

    generated_sql_query = state.generated_sql_query

    response = execute_query(generated_sql_query)

    state.sql_query_execution_result = response

    return state


def final_answer(state: agentschema) -> agentschema:

    sql_query_execution_result = state.sql_query_execution_result

    response = llm.invoke(
        f"""
        Generate a clear final answer for the user
        based on the SQL query execution result.

        SQL result:
        {sql_query_execution_result}

        Give only the answer to the user.
        """
    )

    state.final_answer = response.content

    return state